from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import user_passes_test
from .models import Course, StudentDetails, Feedback, LeaveRequest, HostelFeeDetails,StudentFeeReceipt
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import FeeReceiptForm, StudentForm
from django.db.models import Q

def add_user(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        # Check if the username already exists
        if User.objects.filter(username=username).exists():
            error_message = "Username already exists."
            return render(request, 'adduser.html', {'error_message': error_message})
        
        # Create the user
        User.objects.create_user(username=username, password=password)
        messages.success(request, 'User added successfully!')
        return redirect('add_user')

    return render(request, 'adduser.html')

       
def add_course(request):
    if request.method == 'POST':
        course_name = request.POST['course_name']

        # Check if the course name already exists
        if Course.objects.filter(name=course_name).exists():
            error_message = "Course name already exists."
            return render(request, 'addcourse.html', {'error_message': error_message})
        
        # Create the course
        Course.objects.create(name=course_name)
        success_message = "Course added successfully!"
        return render(request, 'addcourse.html', {'success_message': success_message})

    return render(request, 'addcourse.html')

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        # Authenticate the user
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('landing_page')  # Redirect to the landing page after successful login
        else:
            error_message = "Invalid username or password."
            return render(request, 'login.html', {'error_message': error_message})

    return render(request, 'login.html')

@login_required
def landing_page(request):
    return render(request, 'landing_page.html')

def user_logout(request):
    logout(request)
    return redirect('login')  # Redirect to login page after logout

def add_student(request):
    if request.method == 'POST':
        full_name = request.POST.get('full_name')
        father_name = request.POST.get('father_name')
        mother_name = request.POST.get('mother_name')
        age = request.POST.get('age')
        gender = request.POST.get('gender')
        address = request.POST.get('address')
        course_id = request.POST.get('course_name')
        scholarship = request.POST.get('scholarship')
        admission_date = request.POST.get('admission_date')
        admission_number = request.POST.get('admission_number')
        hosteler = request.POST.get('hosteler')
        status = request.POST.get('status')   # Convert checkbox value to boolean
        
        

        try:
            course = Course.objects.get(id=int(course_id))
        except (ValueError, Course.DoesNotExist):
            error_message = "Invalid course selected."
            return render(request, 'add_student.html', {
                'error_message': error_message,
                'courses': Course.objects.all()
            })

        user = request.user

        student, created = StudentDetails.objects.update_or_create(
            admission_number=admission_number,
            defaults={
                'username': user,
                'full_name': full_name,
                'father_name': father_name,
                'mother_name': mother_name,
                'age': age,
                'gender': gender,
                'address': address,
                'course_name': course,
                'scholarship': scholarship,
                'admission_date': admission_date,
                'hosteler': hosteler,
                'status': status,
            }
        )

        success_message = "Student details added successfully!" if created else "Student details updated successfully!"
        return render(request, 'add_student.html', {
            'success_message': success_message,
            'courses': Course.objects.all()
        })

    courses = Course.objects.all()
    return render(request, 'add_student.html', {
        'courses': courses
    })

def add_feedback(request):
    if request.method == 'POST':
        title = request.POST['title']
        content = request.POST['content']

        try:
            student = StudentDetails.objects.get(username=request.user)
            Feedback.objects.create(student_name=student, title=title, content=content)
            messages.success(request, "Feedback submitted successfully!")
        except StudentDetails.DoesNotExist:
            messages.error(request, "Student details not found.")
        
        return redirect('add_feedback')

    return render(request, 'add_feedback.html')

def add_leave_request(request):
    if request.method == 'POST':
        subject = request.POST['subject']
        from_date = request.POST['from_date']
        to_date = request.POST['to_date']
        status = 'Pending'

        try:
            student = StudentDetails.objects.get(username=request.user)
            LeaveRequest.objects.create(
                student_name=student,
                subject=subject,
                from_date=from_date,
                to_date=to_date,
                status=status
            )
            messages.success(request, "Leave request submitted successfully!")
        except StudentDetails.DoesNotExist:
            messages.error(request, "Student details not found.")
        
        return redirect('add_leave_request')

    return render(request, 'add_leave_request.html')

def courses(request):
    courses = Course.objects.all()
    return render(request, 'course_list.html', {'courses': courses})



def course_students(request, course_id):
    course = get_object_or_404(Course, id=course_id)

    # Retrieve search query from GET parameters
    query = request.GET.get('q', '')
    
    # Filter students based on the search query
    students = StudentDetails.objects.filter(course_name=course)

    if query:
        students = students.filter(
            Q(full_name__icontains=query) |
            Q(father_name__icontains=query) |
            Q(mother_name__icontains=query) |
            Q(age__icontains=query) |
            Q(gender__icontains=query) |
            Q(address__icontains=query) |
            Q(scholarship__icontains=query) |
            Q(admission_number__icontains=query)
        )
    
    context = {
        'course': course,
        'students': students,
        'total_seats': course.total_seats,
        'occupied_seats': course.occupied_seats,
        'available_seats': course.available_seats(),
        'query': query  # Pass the query back to the template
    }
    return render(request, 'course_students.html', context)



def feedback_list(request):
    feedbacks = Feedback.objects.all().select_related('student_name')
    return render(request, 'feedback_list.html', {'feedbacks': feedbacks})

def view_leave_requests(request):
    if request.method == 'POST':
        request_id = request.POST.get('request_id')
        action = request.POST.get('action')
        
        try:
            leave_request = LeaveRequest.objects.get(id=request_id)
            leave_request.status = 'Approved' if action == 'approve' else 'Denied'
            leave_request.save()
            messages.success(request, "Leave request updated successfully!")
        except LeaveRequest.DoesNotExist:
            messages.error(request, "Leave request not found.")
        
        return redirect('view_leave_requests')
    
    leave_requests = LeaveRequest.objects.all()
    return render(request, 'view_leave_requests.html', {'leave_requests': leave_requests})

def student_leave_status(request):
    try:
        student = StudentDetails.objects.get(username=request.user)
        leave_requests = LeaveRequest.objects.filter(student_name=student)
        return render(request, 'status_leave.html', {'leave_requests': leave_requests})
    except StudentDetails.DoesNotExist:
        return render(request, 'status_leave.html', {'error_message': 'Student details not found.'})




@login_required
def hostel_fee_details(request):

    try:
        # Fetch the student details for the logged-in user
        student_details = StudentDetails.objects.filter(username=request.user).first()
        if not student_details:
            return render(request, 'hostel_fee_details.html', {'error_message': 'Student details not found.'})

        # Fetch or create the hostel fee details for the student
        hostel_fee_details, created = HostelFeeDetails.objects.get_or_create(
            student=student_details,
            defaults={'fee_amount': 0.00}
        )

    except StudentDetails.DoesNotExist:
        return render(request, 'hostel_fee_details.html', {'error_message': 'Student details not found.'})

    if request.method == 'POST':
        form = FeeReceiptForm(request.POST, request.FILES, instance=hostel_fee_details)
        if form.is_valid():
            hostel_fee_details = form.save(commit=False)
            hostel_fee_details.save()
            # Create a new StudentFeeReceipt entry
            StudentFeeReceipt.objects.create(
                student=student_details,
                receipt_file=hostel_fee_details.fee_receipt,
                
            )
            messages.success(request, "Receipt uploaded successfully!")
            return redirect('hostel_fee_details')
    else:
        form = FeeReceiptForm(instance=hostel_fee_details)

    context = {
        'student_details': student_details,
        'form': form,
        'receipt': hostel_fee_details  # Pass the receipt to the template
    }
    return render(request, 'hostel_fee_details.html', context)

@login_required
def hostel_fee_receipts_view(request):
    if not request.user.is_superuser:
        return redirect('home')  # Redirect to home if not superuser

    receipts = StudentFeeReceipt.objects.select_related('student').all()  # Fetch all receipts with related student details

    return render(request, 'hostel_fee_receipts.html', {'receipts': receipts})






def edit_student(request, student_id):
    
    student = get_object_or_404(StudentDetails, id=student_id)  # Use StudentDetails instead of Student
    courses = Course.objects.all()  # Fetch all courses
    
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, 'Student details updated successfully!')
            return redirect('edit_student', student_id=student.id)
        else:
            print(form.errors)  # Print errors to the console for debugging
            messages.error(request, "There were errors in the form. Please check the inputs.")
    else:
        form = StudentForm(instance=student)
    
    return render(request, 'edit_student.html', {'form': form, 'student': student, 'courses': courses})

def admin_required(view_func):
    return user_passes_test(lambda u: u.is_superuser)(view_func)


@admin_required
def edit_student_admin(request, student_id):
    student = get_object_or_404(StudentDetails, id=student_id)
    courses = Course.objects.all()
    
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, 'Student details updated successfully!')
            return redirect('edit_student_admin', student_id=student.id)
        else:
            print(form.errors)
            messages.error(request, "There were errors in the form. Please check the inputs.")
    else:
        form = StudentForm(instance=student)
    
    return render(request, 'edit_student_admin.html', {'form': form, 'student': student, 'courses': courses})

@login_required
def view_student_details(request):
    # Fetch the student's details using the correct field name 'username'
    try:
        student = StudentDetails.objects.get(username=request.user)
        return render(request, 'view_student_details.html', {'student': student})
    except StudentDetails.DoesNotExist:
        messages.error(request, "Student details not found.")
        return redirect('landing_page')
    




    