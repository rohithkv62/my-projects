from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver




class Course(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    total_seats = models.PositiveIntegerField(default=0)  # Total number of seats

    def __str__(self):
        return self.name

    def available_seats(self):
        # Calculate available seats dynamically based on the number of students
        return self.total_seats - self.occupied_seats()

    def occupied_seats(self):
        # Calculate occupied seats dynamically based on the number of students
        return StudentDetails.objects.filter(course_name=self).count()


class StudentDetails(models.Model):
    STATUS_CHOICES = [
    ('Active', 'Active'),
    ('Discontinued', 'Discontinued'),
    ('Passout', 'Passout'),
   
]
    username = models.ForeignKey(User, on_delete=models.CASCADE)  # Link to the User model
    full_name = models.CharField(max_length=255)  # Full name of the student
    father_name = models.CharField(max_length=255)  # Father's name
    mother_name = models.CharField(max_length=255)  # Mother's name
    age = models.PositiveIntegerField()  # Age of the student
    gender = models.CharField(max_length=10)  # Gender (e.g., Male, Female, etc.)
    address = models.TextField()  # Address of the student
    course_name = models.ForeignKey(Course, on_delete=models.CASCADE)  # Link to the Course model
    scholarship = models.CharField(max_length=200, null=True, blank=True)  # Scholarship amount (nullable)
    admission_date = models.DateField()  # Admission date
    admission_number = models.CharField(max_length=6, unique=True)  # 6-digit unique admission number
    hosteler = models.BooleanField(default=False)  # True for hosteler, False for non-hosteler
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Active')

    def save(self, *args, **kwargs):
        if self.pk:
            # Existing instance, so update occupied seats
            previous_instance = StudentDetails.objects.get(pk=self.pk)
            if previous_instance.course_name != self.course_name:
                # Update the old course
                previous_course = previous_instance.course_name
                previous_course.save()  # Ensure that the old course is updated properly
               
                # Update the new course
                new_course = self.course_name
                new_course.save()  # Ensure that the new course is updated properly
        else:
            # New student
            course = self.course_name
            course.save()  # Ensure that the course is updated properly
       
        super().save(*args, **kwargs)

# Feedback model to store student feedback
class Feedback(models.Model):
    id = models.AutoField(primary_key=True)  # Auto-incrementing primary key
    student_name = models.ForeignKey(StudentDetails, on_delete=models.CASCADE)  # Link to the StudentDetails model
    title = models.CharField(max_length=100)  # Title of the feedback
    content = models.TextField()  # Content of the feedback

    def __str__(self):
        return self.title

# LeaveRequest model to store leave requests from students
class LeaveRequest(models.Model):
    PENDING = 'Pending'
    APPROVED = 'Approved'
    DENIED = 'Denied'
    STATUS_CHOICES = [
        (PENDING, 'Pending'),
        (APPROVED, 'Approved'),
        (DENIED, 'Denied')
    ]

    id = models.AutoField(primary_key=True)  # Auto-incrementing primary key
    student_name = models.ForeignKey(StudentDetails, on_delete=models.CASCADE)  # Link to the StudentDetails model
    subject = models.CharField(max_length=100)  # Subject of the leave request
    from_date = models.DateField()  # Start date of the leave
    to_date = models.DateField()  # End date of the leave
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=PENDING)  # Status of the leave request

    def __str__(self):
        return f"{self.student_name.full_name} - {self.subject}"
 


# HostelFeeDetails model to store hostel fee information and receipts
class HostelFeeDetails(models.Model):
    student = models.OneToOneField(StudentDetails, on_delete=models.CASCADE, related_name='hostel_fee_details')
    fee_amount = models.DecimalField(max_digits=10, decimal_places=2)
    fee_receipt = models.FileField(upload_to='fee_receipts/', null=True, blank=True)
    receipt_uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.full_name} - Fee Details"

class StudentFeeReceipt(models.Model):
    student = models.ForeignKey(StudentDetails, on_delete=models.CASCADE)
    receipt_file = models.FileField(upload_to='fee_receipts/')
   
   

    def __str__(self):
        return f"Receipt for {self.student.full_name}"

