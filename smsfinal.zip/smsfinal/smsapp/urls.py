from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from .views import *  # This imports all views from views.py
from . import views

    
urlpatterns = [
    path('add_user/', add_user, name='add_user'),
    path('add_course/', add_course, name='add_course'),
    path('', user_login, name='login'),
    path('landing/', landing_page, name='landing_page'),
    path('logout/', user_logout, name='logout'),
    path('add_student/', add_student, name='add_student'),
    path('add_feedback/', add_feedback, name='add_feedback'),
    path('add_leave_request/', add_leave_request, name='add_leave_request'),
    path('courses/', courses, name='courses'),
    path('courses/<int:course_id>/students/', course_students, name='course_students'),
    path('feedback/', feedback_list, name='feedback_list'),
    path('view_leave_requests/', view_leave_requests, name='view_leave_requests'),
    path('leave-status/', student_leave_status, name='student_leave_status'),
    path('hostel_fee_details/', hostel_fee_details, name='hostel_fee_details'),
    path('hostel_fee_receipts/', hostel_fee_receipts_view, name='hostel_fee_receipts'),
    path('edit-student/<int:student_id>/', edit_student, name='edit_student'),
    path('admin/edit-student/<int:student_id>/', edit_student_admin, name='edit_student_admin'),
    path('student/details/', views.view_student_details, name='view_student_details'),


] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
