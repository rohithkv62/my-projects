from django import forms
from .models import HostelFeeDetails, StudentDetails, Course
class FeeReceiptForm(forms.ModelForm):
    class Meta:
        model = HostelFeeDetails
        fields = ['fee_receipt']

class StudentForm(forms.ModelForm):
    class Meta:
        model = StudentDetails
        fields = ['full_name', 'father_name', 'mother_name', 'age', 'gender', 'address', 'course_name', 'scholarship', 'admission_date', 'admission_number', 'hosteler','status',]
        widgets = {
            'course_name': forms.Select(),  # Ensure ForeignKey is rendered as a dropdown
            'address': forms.Textarea(attrs={'rows': 3}),
            'admission_date': forms.DateInput(attrs={'type': 'date'}),
            'gender': forms.Select(choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')]),
            'hosteler': forms.Select(choices=[(True, 'Yes'), (False, 'No')]),
            
        
        }